#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <windows.h>
#define MAX_WORD_LEN 100
/*this is our node for words*/
struct node {
    char word[MAX_WORD_LEN];
    struct node *next;

};
struct player {
    char name[50];
    int last_level;
    double score;

};
struct player_info {
    char file[50];
    char name[50];
    int num;
    int score_type;

};
struct node *word_list;
/*this function adds new node to front of the list*/
void add_front (struct node **plist, struct node *new_node){
    new_node->next = *plist;
    *plist = new_node;
}

/*this function adds new node to end of the list */
void add_end (struct node *list, struct node * new_node){
    struct node *current;
    for(current = list; current-> next != NULL; current = current->next);
    current->next = new_node;
    new_node->next = NULL;
}

/*this is the function that make a linked list for words*/
struct node *create_word_list (char word_arr[][MAX_WORD_LEN], int size){
    int i;
    struct node *word_list = NULL;
    for(i = 0; i < size; i++)
    {
        struct node *new_node = (struct node *)malloc(sizeof(struct node));
        if(new_node == NULL){
            printf("Cannot create node\n");
            exit(-1);
        }
        strcpy(new_node->word, word_arr[i]);
        new_node->next=NULL;
        if(word_list == NULL)
            add_front(&(word_list),new_node);
        else
            add_end(word_list,new_node );
    }

    return word_list;
}



/*this function counts the words in each file*/

int countwords (FILE *fp)
{
    int i=-1;
    char word[50];
    while(1){
        if (feof(fp))
            break;
        fscanf(fp,"%s",word);
        i++;
    }
    fseek(fp,0,SEEK_SET);
    return i;

}
/*this function puts the words of file in a multiply array*/
void put_words_in_array (char arr[][MAX_WORD_LEN],FILE *fp,int size)
{
    int i;

    for (i=0;i<size;i++)
    {
        fscanf(fp,"%s",&arr[i]);
    }
    fseek(fp,0,SEEK_SET);
}
/*this function will choose a random node from the linked list and print it!  */
struct node * print_random_word (struct node **word_list ,int size)
{
    struct node *tmp,*current,*random_word;
    int j,random;
    random_word = (struct node *)malloc(sizeof(struct node));
    if (random_word == NULL)
    {
        printf("cannot malloc");
        exit(-1);
    }
    //printf("%d \n", size);

       current = *word_list ;

        random = rand() % size;
        for (j=0; j<random; j++)
        {
            current = current->next;
        }

        strcpy(random_word->word , current->word);
        if(current == *word_list)
        {
            tmp = *word_list ;
            *word_list = (*word_list)->next;

            free(tmp);
             //printf("%d", random);
           // printf("%s",*word_list->word);
        }
       else
        {
            for(tmp=(*word_list);tmp->next!=current;tmp=tmp->next);
            tmp->next=tmp->next->next;
            free(current);
        }
        //printf("%d", random);
        return random_word;



}

/*this is a function for printing the word after each change and make letter to upper letter ! */
void print_word (char *word_arr , int a,int level)
{
    system("CLS");
    int b;
    b = word_arr[a];
    word_arr [a] = b - 32;
    printf("LEVEL %d\n",level);
    printf("\t\t\t\t\t\t%s\n" , word_arr);

}
/*this function measures score for each word */
double measure_word_score (float time,int wrong_letter,int word_size)
{
    double score;
    score = ((3*word_size) - (wrong_letter)) / time ;
    return score;
}
/*this function will measure score for each level */
double measure_level_score (int number_of_words , double word_scores[])
{
    int i;
    double score , sum = 0;
    for (i=0; i<number_of_words; i++)
       sum += word_scores[i];
    score = sum / number_of_words ;
    return score ;

}
/*this function will measure players_score*/
double measure_player_score (int number_of_levels , double level_scores[])
{
    int i;
    double score = 0;
    for (i=0; i<number_of_levels; i++)
        score += level_scores[i];
    return score;
}
/*this function is a different score measuring function! */
double WPM_level_score (int number_of_words , float time)
{
    double score = number_of_words / (time / 60) ;
    return score;
}
double WPM_player_score (int number_of_levels , double level_score[])
{
    int i;
    double score = 0;
    for (i=0; i<number_of_levels; i++)
        score += level_score[i];
    return score ;
}
/*this function will Quit the game ! */
void quit (char file_name[50],char name[50],int last_level , double score)
{
    char a;
    FILE *fp;
    printf("Do you want to save the game ?![y/n]");
    a = getch();
    if (a == 'y')
    {
        fp = fopen(file_name,"w");
        if (fp == NULL)
            printf("cannot open the file (in quit function)");
        fprintf(fp,"%s , %d , %lf",name,last_level,score);
        fclose(fp);
        return;
    }
    else if (a == 'n')
    {
        printf("See You next time ...\n");
        return;
    }
    else
    {
        Beep(2000,200);
        while (1)
        {
        printf("please Enter y for YES answer and n for NO!");
        a = getch();
        if ((a == 'y')||(a == 'n'))
            break;
        Beep(2000,200);
        }
    }
    if (a == 'y')
    {
        fp = fopen(file_name,"w");
        fprintf(fp,"%s , %d , %lf",name,last_level,score);
        fclose(fp);
        return;
    }
    else if (a == 'n')
    {
        printf("See You next time ...\n");
        return;
    }
}
/*this function will manage pausing the game ! */
void pause ()
{
    char a;
    while (1)
    {
        //system("CLS");
        printf("\nGame is Paused . Enter R to resume the game!\n");
        a = getch();
        if (a == 'R')
            break;
    }
}
/*this function plays each level! */
double play_level (FILE *fp,int level,int score_type)
{
    int size,j,i,random,n,word_size,count_wrong_letter=0;
    char in_harf;
    struct node *s;
    size=countwords(fp);//i = number of words in the file;
    double word_score[size] , level_score;
    char word[size][MAX_WORD_LEN];
    put_words_in_array(word,fp,size);

    //struct node *word_list,*tmp;
    struct node *tmp;
    word_list = create_word_list (word,size);
    n = size;
    float t;
    for (j=0; j<n; j++)//this for is for each file and show its words;
    {
        s = print_random_word(&word_list ,size);
        printf("LEVEL %d\n",level);
        printf("\t\t\t\t\t\t%s \n" , s->word);
        float shoroo = 0 , payan = 0 ;
        clock_t start = clock();//here time startS//
        word_size = strlen(s->word);
        char word_arr[word_size];
        strcpy(word_arr , s->word);
        count_wrong_letter = 0;
        //printf("%s ", word_arr);
        for (i=0; i<word_size; i++)//this is for each word in file;
        {

            while (1)
            {
                in_harf = getch();
                if ((in_harf == 'Q'))//age Q bzane -1 return mishe va bayad bazi ghat she havas bashad !
                    return -1;
                else if ((in_harf == 'R'))
                {
                    printf("U did not pause the game to Resume it !Keep Playing!");
                }
                else if ((in_harf == 'P'))
                {
                    clock_t shoroo = clock();
                    pause();
                    clock_t payan = clock();

                }

                else if (in_harf == word_arr[i])
                {
                    print_word(word_arr , i,level);
                    break;
                }
                else
                {
                    Beep(1000 , 100);

                    count_wrong_letter++;
                }


            }
        }
        clock_t end = clock();
        float time = (float)((end - start) - (shoroo - payan)) / CLOCKS_PER_SEC;
        t = time;
        word_score[j] = measure_word_score(time ,count_wrong_letter,word_size );
        system("CLS");//to clear the screen after we complete the word;

        size--;
    }
    if (score_type == 1)
     {
        level_score = measure_level_score(n ,word_score);
     }
    else
        level_score = WPM_level_score(n ,t );
    return level_score;
}
/*this function will count the levels */

int count_levels ()
{
   int x = 1 ,counter = 0;
    FILE *fp;
    char inname[200];

    char str1[10];
    char str2[5];
    strcpy(str2 , ".txt");
    while (1)
    {
    strcpy(inname ,"levels//level-");
    sprintf(str1 , "%d" ,x);
    strcat(inname ,str1);
    strcat(inname , str2);

    fp = fopen(inname,"r");
    if (fp == NULL)
    {
        //printf("ridi\n");
        break;
    }
    //printf("%s \n",inname);
        counter++;
        x++;
        fclose(fp);
    }
    //printf("x=%d , counter%d",x,counter);
    return counter;
}
/*this function puts level names in array*/
void put_levels_in_array (char level_name[][100],int levels)
{
    int x = 1;
    FILE *fp;
    char inname[200];
    char str1[10];
    char str2[5];
    strcpy(str2 , ".txt");
    for (x=1; x<=levels; x++)
    {
    strcpy(inname ,"levels//level-");
    sprintf(str1 , "%d" ,x);
    strcat(inname ,str1);
    strcat(inname , str2);
    strcpy(level_name[x],inname);

    }
}
/*this function shows the main menu in start of the game */
struct player_info main_menu ()
{
    char game,b[1],score;
    FILE *fp;
    char player_name[50];
    char str1[5] =".txt";
    char file_name[55];
    struct player_info info;
    printf("Welcome To The Typing Test! \nPlease enter your name : ");
    scanf("%s" ,player_name);
    strcpy(info.name,player_name);
    strcpy(file_name,player_name);
    strcat(file_name,str1);
    fp = fopen(file_name , "r+");
    if (fp == NULL)
    {
        printf("This is Your first Game! :D WElCOME!Please start a new game.\n");
        fp = fopen(file_name , "w+");

    }
    strcpy(info.file , file_name);
    printf("%s",info.file);

    fclose(fp);
    system("CLS");
    printf("Welcome %s \n\nAre U Ready to play ?!\n\n",player_name);
    printf("Please choose one of the measuring score types:\n\n");
    printf("[1]Dr.Bakhshis score measure!!\n\n[2]My score measure!!!");
    score = getch();
    system("CLS");
    if (score == '1')
    {
        b[0] = score;
        info.score_type = atoi(b) ;
        printf("\n%d",info.score_type);
    }
    else if (score == '2')
     {
        b[0] = score;
        info.score_type = atoi(b) ;
        printf("\n%d",info.score_type);
     }
    else
    {
        Beep(1000,200);
        while (1)
        {
            system("CLS");
            printf("[1]Dr.Bakhshis score measure!!\n\n[2]My score measure!!!\n\n");
            printf("Wrong input!!Please enter 1 or 2 !!");
            score = getch();
            if (score == '1')
            {
                b[0] = score;
                info.score_type = atoi(b) ;
                break;
            }
            if (score == '2')
            {
                b[0] = score;
                info.score_type = atoi(b) ;
                break;
            }
            Beep(1000,200);
        }
    }
    system("CLS");
    printf("Please choose one:\n");
    printf("[1]Play a new game!\n\n\n[2]Resume an Old game!");
    game = getch();
    system("CLS");
    if (game == '1')
    {
        b[0] = game;
        if (info.score_type == 1)
            info.num = atoi(b)- 110;
        else
            info.num = atoi(b) - 111;
        printf("\n%d",info.num);
    }
    else if (game == '2')
     {
        b[0] = game;
        if (info.score_type == 1)
            info.num = atoi(b) - 219;
        else
            info.num = atoi(b) - 220;
        printf("\n%d",info.num);
     }
    else
    {
        Beep(1000,200);
        while (1)
        {
            system("CLS");
            printf("[1]Play a new game!\n\n\n[2]Resume an Old game!\n\n");
            printf("Wrong input!!Please enter 1 or 2 !!");
            game = getch();
            if (game == '1')
            {
                b[0] = game;
                if (info.score_type == 1)
                    info.num = atoi(b)- 110;
                else
                    info.num = atoi(b) - 111;
                break;
            }
            if (game == '2')
            {
                b[0] = game;
                if (info.score_type == 1)
                    info.num = atoi(b) - 219;
                else
                    info.num = atoi(b) - 220;
                break;
            }
            Beep(1000,200);
        }
    }
    //printf("%d",info.name);
    return info;

}
/*this function will do the new game mode; */
void new_game (int levels , char level_name[][100],char file_name[50],char player_name[50],int score_type)
{
    int i,n = 0,j;
    FILE *fp;
    char a;
    double player_score;
    char level_stri[100];
    char level_str[100];
    printf("Ok!Let's start!\n\nWhich level you want to play ?(there is just -%d- levels)\n",levels);
    scanf("%s",&level_str);
    while (1)
    {


        for (i=1; i<=levels; i++)
        {

            sprintf(level_stri,"%d",i);
            if (strcmp(level_str,level_stri)==0)
            {
                n = i;
                break;
            }
        }
        if (n == i)
            break;
        printf("Wrong input.Please enter a number between 1 and %d\n",levels);
        scanf("%s",&level_str);
    }
    j = n;
    int number_of_levels  = levels - n + 1 ;
    double level_score[number_of_levels] ;
    for (i=0; i<number_of_levels; i++)
        level_score[i] = 0 ;
    for (i=0; i<number_of_levels; i++)
    {
        system("CLS");
        fp = fopen(level_name[n],"r");
        if (fp == NULL)
        {
            printf("cannot open the file (in new_game)");
            exit(-1);
        }
        level_score[i] = play_level(fp,n,score_type);
        if (level_score[i] == -1)
        {
            quit(file_name,player_name,n,measure_player_score(i - 1 ,level_score));
            return;
        }
        //printf("%lf\n",level_score[i]);
        //inja bayad bporse ke edame mikhay bdi beri level baad ya na ?
        printf("You score in this level is : %lf\n\n",level_score[i]);
        if (n == levels)
            printf("\t\t\t\t\t\tGame is finished!\n");
        if (n != levels)
        {
            n++;//n uses for choosing name of the level in the array;
            printf("Do U want to continue to next level?[y/n]\n\n");
            a = getch();
            if (a == 'y')
                continue;
            else if (a == 'n')
                break;
            else
            {
                Beep(2000,200);
                while (1)
                {
                printf("please Enter y for YES answer and n for NO!");
                a = getch();
                if ((a == 'y')||(a == 'n'))
                    break;
                Beep(2000,200);
                }
            }
            if (a == 'y')
                continue;
            else if (a == 'n')
                break;
            fclose(fp);
        }
    }
    if (score_type == 1)
        player_score = measure_player_score(number_of_levels,level_score);
    else
        player_score = WPM_player_score (number_of_levels,level_score);
    if (n == levels)
    {
        printf("Your total score is :%lf\n\n",player_score);
        //printf("%lf",level_score[0]);
    }
    printf("Do you want to save your current level and score ?[y/n]\n\n");
    a = getch();
    if (a == 'y')
    {
        //if (j != levels)
            //n += 1 ;
        fp = fopen(file_name,"w");
        printf("%s", file_name);
        fprintf(fp,"%s , %d , %lf ",player_name ,n ,player_score);
        fclose(fp);
        return;
    }
    else if (a == 'n')
    {
        printf("See U Next time ...");
        return;
    }
    else
    {
        while (1)
        {
            system("CLS");
            printf("Please enter y for YES answer and n for NO !");
            a = getch();
            if (a == 'y')
            {
                //if (j != levels)
                    //n += 1 ;
                fp = fopen(file_name,"w");
                fprintf(fp,"%s , %d , %lf ",player_name ,n ,player_score);
                fclose(fp);
                break;
            }
            if (a == 'n')
            {
                printf("See U Next time ...");
                break;
            }
        }
    }
    return;


}
/*this function is for doing Resume works! */
int resume_game (int levels , char level_name[][100],char file_name[50],char player_name[50],int score_type)
{
    FILE *fp;
    int last_level,x,i,number_of_levels,n,j;
    double score,player_score;
    char player[50];
    char a;
    fp = fopen(file_name,"r+");
    x = countwords(fp);
    if (x == 0)
    {
        printf("U did not play this game before Or U did not save your information. Please choose new Game\n");
        return -1;
    }
    //fclose(fp);

    fscanf(fp,"%s , %d , %lf",&player,&last_level ,&score);
    printf("your last level that played was:[%d] And your saved score is : %lf\n\n",last_level,score);
    number_of_levels = levels - last_level + 1;
    double level_score[number_of_levels] ;
    j = n = last_level;
    for (i=0; i<number_of_levels; i++)
        level_score[i] = 0 ;
    for (i=0; i<number_of_levels; i++)
    {
        //system("CLS");
        fp = fopen(level_name[n],"r");
        if (fp == NULL)
        {
            printf("cannot open the file (in resume_game)");
            exit(-1);
        }
        level_score[i] = play_level(fp,n,score_type);
        if (level_score[i] == -1)
        {
            quit(file_name,player_name,n,measure_player_score(i  ,level_score));
            return;
        }
    //inja bayad bporse ke edame mikhay bdi beri level baad ya na ?
        printf("You score in this level is : %lf\n\n",level_score[i]);
        if (n == levels)
            printf("\t\t\t\t\t\tGame is finished!\n");
        if (n != levels)
        {
            n++;//n uses for choosing name of the level in the array;
            printf("Do U want to continue to next level?[y/n]\n\n");
            a = getch();
            if (a == 'y')
                continue;
            else if (a == 'n')
                break;
            else
            {
                Beep(2000,200);
                while (1)
                {
                printf("please Enter y for YES answer and n for NO!");
                a = getch();
                if ((a == 'y')||(a == 'n'))
                    break;
                Beep(2000,200);
                }
            }
            if (a == 'y')
                continue;
            else if (a == 'n')
                break;
            fclose(fp);
        }
    }
    if (score_type == 1)
        player_score = measure_player_score(number_of_levels,level_score);
    else
        player_score = WPM_player_score (number_of_levels,level_score);
    if (n == levels)
    {
        printf("Your total score is :%lf\n\n",player_score);
    }
    printf("Do you want to save your current level and score ?[y/n]\n\n");
    a = getch();
    if (a == 'y')
    {
        //if (j != levels)
            //n += 1 ;
        fp = fopen(file_name,"w");
        fprintf(fp,"%s , %d , %lf ",player_name ,n ,player_score);
        fclose(fp);
        return 0;
    }
    else if (a == 'n')
    {
        printf("See U Next time ...");
        return 0;
    }
    else
    {
        while (1)
        {
            system("CLS");
            printf("Please enter y for YES answer and n for NO !");
            a = getch();
            if (a == 'y')
            {
                //if (j != levels)
                    //n += 1 ;
                fp = fopen(file_name,"w");
                fprintf(fp,"%s , %d , %lf ",player_name ,n ,player_score);
                fclose(fp);
                break;
            }
            if (a == 'n')
            {
                printf("See U Next time ...");
                break;
            }
        }
    }
    return 0;





}

int main ()
{
    FILE *fp;
    int size,j,i,random,n,word_size,levels,new_old,resume_return;
    char in_harf;
    struct node *s;
    struct player_info info;
    time_t t = time(NULL);
    srand(t);
    levels = count_levels();
    char level_name[levels][100];
    put_levels_in_array(level_name , levels);
    info = main_menu();
    //printf("\n%d",info.score_type);
    //printf("\n%d",info.num);
    if (info.score_type == 1)
    {
        if (info.num == 1)
        {
            new_game(levels,level_name,info.file,info.name,info.score_type);
        }
        if (info.num == 2)
        {
            resume_return = resume_game(levels,level_name,info.file,info.name,info.score_type);
            if (resume_return == -1)
            {
                new_game(levels,level_name,info.file,info.name,info.score_type);
                return 0;
            }

        }
    }
    if (info.score_type == 2)
    {
        if (info.num == 1)
        {
            new_game(levels,level_name,info.file,info.name,info.score_type);
        }
        if (info.num == 2)
        {
            resume_return = resume_game(levels,level_name,info.file,info.name,info.score_type);
            if (resume_return == -1)
            {
                new_game(levels,level_name,info.file,info.name,info.score_type);
                return 0;
                printf("ss");
            }

        }
    }

    return 0;


}
